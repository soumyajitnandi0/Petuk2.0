package com.example.khaikhai.cart

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.khaikhai.R
import com.squareup.picasso.Picasso

class CartAdapter(
    private var cartItems: List<CartItem>,
    private val onQuantityChanged: (String, Int) -> Unit,
    private val onItemRemoved: (String) -> Unit
) : RecyclerView.Adapter<CartAdapter.CartViewHolder>() {

    class CartViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val itemImageView: ImageView = itemView.findViewById(R.id.itemImageView)
        val itemNameTextView: TextView = itemView.findViewById(R.id.itemNameTextView)
        val itemPriceTextView: TextView = itemView.findViewById(R.id.itemPriceTextView)
        val itemQuantityTextView: TextView = itemView.findViewById(R.id.itemQuantityTextView)
        val decreaseButton: ImageButton = itemView.findViewById(R.id.decreaseButton)
        val increaseButton: ImageButton = itemView.findViewById(R.id.increaseButton)
        val removeButton: ImageButton = itemView.findViewById(R.id.removeButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_cart, parent, false)
        return CartViewHolder(view)
    }

    override fun onBindViewHolder(holder: CartViewHolder, position: Int) {
        val cartItem = cartItems[position]
        val menuItem = cartItem.menuItem

        holder.itemNameTextView.text = menuItem.name
        holder.itemPriceTextView.text = "₹${String.format("%.2f", cartItem.getTotalPrice())}"
        holder.itemQuantityTextView.text = cartItem.quantity.toString()

        // Load image if available
        if (menuItem.imageUrl.isNotEmpty()) {
            Picasso.get()
                .load(menuItem.imageUrl)
                .placeholder(R.drawable.ic_launcher_background)
                .error(R.drawable.ic_launcher_foreground)
                .into(holder.itemImageView)
        } else {
            holder.itemImageView.setImageResource(R.drawable.ic_launcher_background)
        }

        // Set up decrease button
        holder.decreaseButton.setOnClickListener {
            if (cartItem.quantity > 1) {
                onQuantityChanged(menuItem.itemId!!, cartItem.quantity - 1)
            }
        }

        // Set up increase button
        holder.increaseButton.setOnClickListener {
            onQuantityChanged(menuItem.itemId!!, cartItem.quantity + 1)
        }

        // Set up remove button
        holder.removeButton.setOnClickListener {
            onItemRemoved(menuItem.itemId!!)
        }
    }

    override fun getItemCount(): Int = cartItems.size

    fun updateCartItems(newCartItems: List<CartItem>) {
        cartItems = newCartItems
        notifyDataSetChanged()
    }
}
