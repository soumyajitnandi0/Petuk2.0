package com.example.khaikhai.cart

import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.khaikhai.R

class CartActivity : AppCompatActivity() {

    private lateinit var cartManager: CartManager
    private lateinit var adapter: CartAdapter

    private lateinit var recyclerView: RecyclerView
    private lateinit var emptyCartView: TextView
    private lateinit var restaurantNameTextView: TextView
    private lateinit var totalPriceTextView: TextView
    private lateinit var checkoutButton: Button
    private lateinit var clearCartButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cart)

        // Set up toolbar
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Your Cart"

        // Initialize views
        recyclerView = findViewById(R.id.cartRecyclerView)
        emptyCartView = findViewById(R.id.emptyCartView)
        restaurantNameTextView = findViewById(R.id.restaurantNameTextView)
        totalPriceTextView = findViewById(R.id.totalPriceTextView)
        checkoutButton = findViewById(R.id.checkoutButton)
        clearCartButton = findViewById(R.id.clearCartButton)

        // Initialize CartManager
        cartManager = CartManager(this)

        // Set up RecyclerView
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = CartAdapter(
            cartItems = cartManager.getCartItems(),
            onQuantityChanged = { menuItemId, quantity ->
                cartManager.updateItemQuantity(menuItemId, quantity)
                updateUI()
            },
            onItemRemoved = { menuItemId ->
                cartManager.removeItem(menuItemId)
                updateUI()
            }
        )
        recyclerView.adapter = adapter

        // Set up clear cart button
        clearCartButton.setOnClickListener {
            showClearCartConfirmationDialog()
        }

        // Set up checkout button
        checkoutButton.setOnClickListener {
            // Implement checkout functionality
            // For now, just show a message
            AlertDialog.Builder(this)
                .setTitle("Checkout")
                .setMessage("Checkout functionality will be implemented soon!")
                .setPositiveButton("OK", null)
                .show()
        }

        // Update UI
        updateUI()
    }

    private fun updateUI() {
        val cartItems = cartManager.getCartItems()

        if (cartItems.isEmpty()) {
            recyclerView.visibility = View.GONE
            emptyCartView.visibility = View.VISIBLE
            restaurantNameTextView.visibility = View.GONE
            totalPriceTextView.visibility = View.GONE
            checkoutButton.visibility = View.GONE
            clearCartButton.visibility = View.GONE
        } else {
            recyclerView.visibility = View.VISIBLE
            emptyCartView.visibility = View.GONE
            restaurantNameTextView.visibility = View.VISIBLE
            totalPriceTextView.visibility = View.VISIBLE
            checkoutButton.visibility = View.VISIBLE
            clearCartButton.visibility = View.VISIBLE

            // Update restaurant name
            restaurantNameTextView.text = "Restaurant: ${cartManager.getRestaurantName()}"

            // Update total price
            totalPriceTextView.text = "Total: ₹${String.format("%.2f", cartManager.getCartTotal())}"

            // Update adapter
            adapter.updateCartItems(cartItems)
        }
    }

    private fun showClearCartConfirmationDialog() {
        AlertDialog.Builder(this)
            .setTitle("Clear Cart")
            .setMessage("Are you sure you want to clear your cart?")
            .setPositiveButton("Yes") { _, _ ->
                cartManager.clearCart()
                updateUI()
            }
            .setNegativeButton("No", null)
            .show()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            onBackPressed()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
