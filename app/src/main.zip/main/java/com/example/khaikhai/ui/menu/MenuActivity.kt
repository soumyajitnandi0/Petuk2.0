package com.example.khaikhai.ui.menu

import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.khaikhai.R

class MenuActivity : AppCompatActivity() {

    private lateinit var viewModel: MenuViewModel
    private lateinit var adapter: MenuAdapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var emptyView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)

        // Get restaurant ID and name from intent
        val restaurantId = intent.getStringExtra("RESTAURANT_ID") ?: ""
        val restaurantName = intent.getStringExtra("RESTAURANT_NAME") ?: "Restaurant"

        // Set the title in the toolbar
        supportActionBar?.title = restaurantName
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Initialize views
        recyclerView = findViewById(R.id.menuRecyclerView)
        progressBar = findViewById(R.id.progressBar)
        emptyView = findViewById(R.id.emptyView)

        // Set up RecyclerView
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = MenuAdapter(this, emptyList(), restaurantId, restaurantName)
        recyclerView.adapter = adapter

        // Initialize ViewModel
        viewModel = ViewModelProvider(this).get(MenuViewModel::class.java)

        // Observe menu items
        viewModel.menuItems.observe(this) { menuItems ->
            adapter.updateData(menuItems)

            // Show empty view if no items
            if (menuItems.isEmpty()) {
                emptyView.visibility = View.VISIBLE
                recyclerView.visibility = View.GONE
            } else {
                emptyView.visibility = View.GONE
                recyclerView.visibility = View.VISIBLE
            }
        }

        // Observe loading state
        viewModel.isLoading.observe(this) { isLoading ->
            progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        }

        // Observe error messages
        viewModel.errorMessage.observe(this) { errorMessage ->
            if (errorMessage.isNotEmpty()) {
                Toast.makeText(this, errorMessage, Toast.LENGTH_LONG).show()
            }
        }

        // Load menu items for the selected restaurant
        if (restaurantId.isNotEmpty()) {
            viewModel.loadMenuItems(restaurantId)
        } else {
            Toast.makeText(this, "Invalid restaurant ID", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}
