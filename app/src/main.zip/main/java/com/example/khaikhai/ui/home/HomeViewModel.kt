package com.example.khaikhai.ui.home

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class HomeViewModel : ViewModel() {

    private val databaseReference = FirebaseDatabase.getInstance().reference.child("restaurants")

    private val _restaurants = MutableLiveData<List<Restaurant>()
    val restaurants: LiveData<List<Restaurant>> = _restaurants

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    fun loadRestaurants() {
        _isLoading.value = true

        databaseReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                _isLoading.value = false

                val restaurantList = mutableListOf<Restaurant>()
                for (restaurantSnapshot in snapshot.children) {
                    val id = restaurantSnapshot.key ?: continue
                    val name = restaurantSnapshot.child("name").getValue(String::class.java) ?: ""
                    val imageUrl = restaurantSnapshot.child("imageUrl").getValue(String::class.java) ?: ""
                    val rating = restaurantSnapshot.child("rating").getValue(Double::class.java) ?: 0.0
                    val address = restaurantSnapshot.child("address").getValue(String::class.java) ?: ""

                    restaurantList.add(Restaurant(id, name, imageUrl, rating, address))
                }

                _restaurants.value = restaurantList
            }

            override fun onCancelled(error: DatabaseError) {
                _isLoading.value = false
            }
        })
    }
}
