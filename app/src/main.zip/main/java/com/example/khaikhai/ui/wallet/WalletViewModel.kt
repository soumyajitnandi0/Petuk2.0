package com.example.khaikhai.ui.wallet

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class DashboardViewModel : ViewModel() {

    private val _cashbackBalance = MutableLiveData<String>()
    val cashbackBalance: LiveData<String> = _cashbackBalance

    private val _transactionList = MutableLiveData<List<Transaction>>()
    val transactionList: LiveData<List<Transaction>> = _transactionList

    init {
        // Initialize with demo data
        _cashbackBalance.value = "$15.50"
        loadTransactions()
    }

    private fun loadTransactions() {
        // In a real app, this would come from a repository or API call
        val transactions = mutableListOf(
            Transaction(
                id = 1,
                restaurantName = "Burger King",
                date = "May 10, 2025",
                amount = "$1.25",
                isReward = false
            ),
            Transaction(
                id = 2,
                restaurantName = "Pizza Hut",
                date = "May 8, 2025",
                amount = "$2.50",
                isReward = false
            ),
            Transaction(
                id = 3,
                restaurantName = "Cashback Redemption",
                date = "May 5, 2025",
                amount = "$10.00",
                isReward = true
            ),
            Transaction(
                id = 4,
                restaurantName = "Taco Bell",
                date = "May 3, 2025",
                amount = "$0.75",
                isReward = false
            ),
            Transaction(
                id = 5,
                restaurantName = "Sushi Palace",
                date = "Apr 30, 2025",
                amount = "$3.50",
                isReward = false
            )
        )
        _transactionList.value = transactions
    }
}

// Data class for transaction
data class Transaction(
    val id: Int,
    val restaurantName: String,
    val date: String,
    val amount: String,
    val isReward: Boolean
)