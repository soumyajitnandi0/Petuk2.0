package com.example.khaikhai.ui.menu

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import com.example.khaikhai.R
import com.example.khaikhai.cart.AddToCartResult
import com.example.khaikhai.cart.CartManager
import com.squareup.picasso.Picasso

class MenuAdapter(
    private val context: Context,
    private var menuItems: List<MenuItem>,
    private val restaurantId: String,
    private val restaurantName: String
) : RecyclerView.Adapter<MenuAdapter.ViewHolder>() {

    private val cartManager = CartManager(context)

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nameTextView: TextView = itemView.findViewById(R.id.text_menu_item_name)
        val descriptionTextView: TextView = itemView.findViewById(R.id.text_menu_item_description)
        val priceTextView: TextView = itemView.findViewById(R.id.text_menu_item_price)
        val addToCartButton: Button = itemView.findViewById(R.id.addToCartButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_menu, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val menuItem = menuItems[position]

        holder.nameTextView.text = menuItem.name
        holder.descriptionTextView.text = menuItem.description
        holder.priceTextView.text = "₹${menuItem.price}"

        // Load image if available
        if (menuItem.imageUrl.isNotEmpty()) {
            Picasso.get()
                .load(menuItem.imageUrl)
                .placeholder(R.drawable.ic_launcher_background)
                .error(R.drawable.ic_launcher_foreground)
                .into(holder.imageView)
        } else {
            holder.imageView.setImageResource(R.drawable.ic_launcher_background)
        }

        // Set up add to cart button
        holder.addToCartButton.isEnabled = menuItem.isAvailable
        holder.addToCartButton.alpha = if (menuItem.isAvailable) 1.0f else 0.5f

        holder.addToCartButton.setOnClickListener {
            if (!menuItem.isAvailable) {
                Toast.makeText(
                    context,
                    "Sorry, ${menuItem.name} is currently unavailable",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            when (val result = cartManager.addItem(menuItem, restaurantId, restaurantName)) {
                is AddToCartResult.Success -> {
                    Toast.makeText(
                        context,
                        "${menuItem.name} added to cart",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                is AddToCartResult.DifferentRestaurant -> {
                    showDifferentRestaurantDialog(result.currentRestaurantName, menuItem)
                }
            }
        }
    }

    private fun showDifferentRestaurantDialog(currentRestaurantName: String, menuItem: MenuItem) {
        AlertDialog.Builder(context)
            .setTitle("Clear Cart?")
            .setMessage("Your cart contains items from $currentRestaurantName. Do you want to clear your cart and add items from $restaurantName?")
            .setPositiveButton("Yes") { _, _ ->
                cartManager.clearCart()
                cartManager.addItem(menuItem, restaurantId, restaurantName)
                Toast.makeText(
                    context,
                    "${menuItem.name} added to cart",
                    Toast.LENGTH_SHORT
                ).show()
            }
            .setNegativeButton("No", null)
            .show()
    }

    override fun getItemCount(): Int {
        return menuItems.size
    }

    fun updateData(newMenuItems: List<MenuItem>) {
        menuItems = newMenuItems
        notifyDataSetChanged()
    }
}
