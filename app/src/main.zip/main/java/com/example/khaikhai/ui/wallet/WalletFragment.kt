package com.example.khaikhai.ui.wallet

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.khaikhai.databinding.FragmentWalletBinding

class WalletFragment : Fragment() {

    private var _binding: FragmentWalletBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!
    private lateinit var transactionAdapter: TransactionAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val dashboardViewModel =
            ViewModelProvider(this).get(DashboardViewModel::class.java)

        _binding = FragmentWalletBinding.inflate(inflater, container, false)
        val root: View = binding.root

        // Set up cashback balance
        val balanceTextView: TextView = binding.textBalanceAmount
        dashboardViewModel.cashbackBalance.observe(viewLifecycleOwner) {
            balanceTextView.text = it
        }

        // Set up redeem button
        val redeemButton: Button = binding.btnRedeem
        redeemButton.setOnClickListener {
            // Show a toast message for now
            Toast.makeText(context, "Redeeming cashback...", Toast.LENGTH_SHORT).show()
            // Later this would call a method in the ViewModel
        }

        // Set up recycler view for transactions
        binding.rvTransactions.layoutManager = LinearLayoutManager(context)
        transactionAdapter = TransactionAdapter()
        binding.rvTransactions.adapter = transactionAdapter

        // Observe transaction list
        dashboardViewModel.transactionList.observe(viewLifecycleOwner) { transactions ->
            transactionAdapter.submitList(transactions)
        }

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}