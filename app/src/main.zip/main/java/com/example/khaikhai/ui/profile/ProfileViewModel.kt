package com.example.khaikhai.ui.profile

import android.content.Context
import android.content.SharedPreferences
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.khaikhai.Customer
import com.example.khaikhai.R
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class ProfileViewModel : ViewModel() {

    private val _userProfile = MutableLiveData<Customer?>()
    val userProfile: LiveData<Customer?> = _userProfile

    private val _userName = MutableLiveData<String>()
    val userName: LiveData<String> = _userName

    private val _userEmail = MutableLiveData<String>()
    val userEmail: LiveData<String> = _userEmail

    private val _userPhone = MutableLiveData<String>()
    val userPhone: LiveData<String> = _userPhone

    private val _userBio = MutableLiveData<String>()
    val userBio: LiveData<String> = _userBio

    private val _isLoading = MutableLiveData<Boolean>(false)
    val isLoading: LiveData<Boolean> = _isLoading

    private val _profileOptions = MutableLiveData<List<ProfileOption>>()
    val profileOptions: LiveData<List<ProfileOption>> = _profileOptions

    private val database = FirebaseDatabase.getInstance()
    private val customersRef = database.reference.child("customers")

    private lateinit var sharedPreferences: SharedPreferences
    private var customerId: String? = null

    init {
        loadProfileOptions()
    }

    fun initialize(context: Context) {
        sharedPreferences = context.getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE)
        customerId = sharedPreferences.getString("CUSTOMER_ID", null)
        loadUserProfile()
    }

    private fun loadProfileOptions() {
        val options = listOf(
            ProfileOption(
                id = 1,
                title = "Personal Information",
                iconResId = R.drawable.ic_person_info,
                type = ProfileOptionType.PERSONAL_INFO
            ),
            ProfileOption(
                id = 2,
                title = "Addresses",
                iconResId = R.drawable.ic_location,
                type = ProfileOptionType.ADDRESSES
            ),
            ProfileOption(
                id = 3,
                title = "Order History",
                iconResId = R.drawable.ic_history,
                type = ProfileOptionType.ORDER_HISTORY
            ),
            ProfileOption(
                id = 4,
                title = "Favorites",
                iconResId = R.drawable.ic_favorite,
                type = ProfileOptionType.FAVORITES
            ),
            ProfileOption(
                id = 5,
                title = "Log Out",
                iconResId = R.drawable.ic_logout,
                type = ProfileOptionType.LOGOUT
            )
        )
        _profileOptions.value = options
    }

    fun loadUserProfile() {
        _isLoading.value = true

        if (customerId != null) {
            customersRef.child(customerId!!)
                .addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        _isLoading.value = false
                        if (snapshot.exists()) {
                            val customer = snapshot.getValue(Customer::class.java)
                            customer?.let {
                                _userProfile.value = it
                                _userName.value = it.fullName
                                _userEmail.value = it.email
                                _userPhone.value = it.phone.ifEmpty { "" }
                                _userBio.value = it.bio ?: ""
                            }
                        }
                    }

                    override fun onCancelled(error: DatabaseError) {
                        _isLoading.value = false
                        // Handle error silently
                    }
                })
        } else {
            _isLoading.value = false
            _userName.value = "Not logged in"
            _userEmail.value = "Please log in"
            _userPhone.value = ""
            _userBio.value = ""
        }
    }

    fun logout() {
        // Clear shared preferences
        val editor = sharedPreferences.edit()
        editor.remove("CUSTOMER_ID")
        editor.remove("LOGIN_TIME")
        editor.putBoolean("IS_LOGGED_IN", false)
        editor.apply()

        // Clear user data
        _userProfile.value = null
        _userName.value = ""
        _userEmail.value = ""
        _userPhone.value = ""
        _userBio.value = ""
    }

    fun updateUserProfile(name: String, phone: String, bio: String = "") {
        if (customerId != null) {
            val updates = hashMapOf<String, Any>(
                "fullName" to name,
                "phone" to phone,
                "bio" to bio
            )

            _isLoading.value = true
            customersRef.child(customerId!!).updateChildren(updates)
                .addOnCompleteListener { task ->
                    _isLoading.value = false
                    if (task.isSuccessful) {
                        // Update local data
                        _userName.value = name
                        _userPhone.value = phone
                        _userBio.value = bio

                        // Also update the customer object
                        _userProfile.value?.let {
                            _userProfile.value = it.copy(
                                fullName = name,
                                phone = phone,
                                bio = bio,
                                updatedAt = System.currentTimeMillis()
                            )
                        }
                    }
                }
        }
    }

    fun updateProfileImage(imageUrl: String) {
        if (customerId != null) {
            val updates = hashMapOf<String, Any>(
                "profilePhotoUrl" to imageUrl
            )

            _isLoading.value = true
            customersRef.child(customerId!!).updateChildren(updates)
                .addOnCompleteListener { task ->
                    _isLoading.value = false
                    if (task.isSuccessful) {
                        // Update the customer object
                        _userProfile.value?.let {
                            _userProfile.value = it.copy(
                                profilePhotoUrl = imageUrl
                            )
                        }
                    }
                }
        }
    }
}