package com.example.khaikhai.ui.home

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.khaikhai.R
import com.example.khaikhai.ui.menu.MenuActivity
import android.util.Log

class RestaurantAdapter :
    ListAdapter<Restaurant, RestaurantAdapter.RestaurantViewHolder>(RestaurantDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RestaurantViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_restaurant, parent, false)
        return RestaurantViewHolder(view)
    }

    override fun onBindViewHolder(holder: RestaurantViewHolder, position: Int) {
        val restaurant = getItem(position)
        holder.bind(restaurant)
    }

    class RestaurantViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val nameTextView: TextView = itemView.findViewById(R.id.text_restaurant_name)
        private val cuisineTextView: TextView = itemView.findViewById(R.id.text_restaurant_cuisine)
        private val ratingTextView: TextView = itemView.findViewById(R.id.text_restaurant_rating)
        private val deliveryTimeTextView: TextView = itemView.findViewById(R.id.text_delivery_time)
        private val restaurantImageView: ImageView = itemView.findViewById(R.id.image_restaurant)

        fun bind(restaurant: Restaurant) {
            nameTextView.text = restaurant.name
            cuisineTextView.text = restaurant.cuisine
            // Show rating only if it's greater than 0
            if (restaurant.rating > 0) {
                ratingTextView.text = restaurant.rating.toString()
                ratingTextView.visibility = View.VISIBLE
            } else {
                ratingTextView.visibility = View.GONE
            }
            deliveryTimeTextView.text = restaurant.deliveryTime
            restaurantImageView.setImageResource(restaurant.imageResId)

            // Set click listener for the item
            itemView.setOnClickListener {
                // Log the restaurant ID for debugging
                Log.d("RestaurantAdapter", "Restaurant selected: ${restaurant.name} with ID: ${restaurant.id}")

                // Navigate to MenuActivity with restaurant details
                val context = itemView.context
                val intent = Intent(context, MenuActivity::class.java).apply {
                    putExtra("RESTAURANT_ID", restaurant.id)  // No need for toString() as id is already a String
                    putExtra("RESTAURANT_NAME", restaurant.name)
                    putExtra("RESTAURANT_CUISINE", restaurant.cuisine)
                }
                context.startActivity(intent)
            }
        }
    }

    private class RestaurantDiffCallback : DiffUtil.ItemCallback<Restaurant>() {
        override fun areItemsTheSame(oldItem: Restaurant, newItem: Restaurant): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Restaurant, newItem: Restaurant): Boolean {
            return oldItem == newItem
        }
    }
}