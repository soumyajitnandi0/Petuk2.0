package com.example.khaikhai.ui.home

import android.content.Intent
import android.os.Bundle
import android.view.*
import android.widget.ProgressBar
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.khaikhai.R
import com.example.khaikhai.R.*
import com.example.khaikhai.cart.CartActivity
import com.example.khaikhai.cart.CartManager

class HomeFragment : Fragment() {

    private lateinit var homeViewModel: HomeViewModel
    private lateinit var restaurantAdapter: RestaurantAdapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var emptyView: TextView
    private lateinit var cartManager: CartManager

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val root = inflater.inflate(layout.fragment_home, container, false)

        // Initialize views
        recyclerView = root.findViewById(R.id.rv_restaurants)
        progressBar = root.findViewById(R.id.progressBar)
        emptyView = root.findViewById(R.id.emptyView)

        // Initialize CartManager
        cartManager = CartManager(requireContext())

        // Set up RecyclerView
        recyclerView.layoutManager = LinearLayoutManager(context)
        restaurantAdapter = RestaurantAdapter(requireContext(), emptyList())
        recyclerView.adapter = restaurantAdapter

        // Enable options menu
        setHasOptionsMenu(true)

        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Initialize ViewModel
        homeViewModel = ViewModelProvider(this).get(HomeViewModel::class.java)

        // Observe restaurants
        homeViewModel.restaurants.observe(viewLifecycleOwner) { restaurants ->
            restaurantAdapter.updateData(restaurants)

            // Show empty view if no restaurants
            if (restaurants.isEmpty()) {
                emptyView.visibility = View.VISIBLE
                recyclerView.visibility = View.GONE
            } else {
                emptyView.visibility = View.GONE
                recyclerView.visibility = View.VISIBLE
            }
        }

        // Observe loading state
        homeViewModel.isLoading.observe(viewLifecycleOwner) { isLoading ->
            progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        }

        // Load restaurants
        homeViewModel.loadRestaurants()
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.home_menu, menu)

        // Update cart badge
        updateCartBadge(menu)

        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onResume() {
        super.onResume()
        // Refresh options menu to update cart badge
        activity?.invalidateOptionsMenu()
    }

    private fun updateCartBadge(menu: Menu) {
        val cartItem = menu.findItem(R.id.action_cart)
        val itemCount = cartManager.getCartItemCount()

        if (itemCount > 0) {
            cartItem.setActionView(layout.cart_badge)
            val badge = cartItem.actionView
            val badgeTextView = badge?.findViewById<TextView>(R.id.cart_badge)
            if (badgeTextView != null) {
                badgeTextView.text = itemCount.toString()
            }

            // Set click listener on the badge
            if (badge != null) {
                badge.setOnClickListener {
                    openCartActivity()
                }
            }
        } else {
            cartItem.actionView = null
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_cart -> {
                openCartActivity()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun openCartActivity() {
        val intent = Intent(requireContext(), CartActivity::class.java)
        startActivity(intent)
    }
}
